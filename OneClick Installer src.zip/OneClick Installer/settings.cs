﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Reflection;

namespace OneClick_Installer
{
    public partial class settings : MetroFramework.Forms.MetroForm
    {
        public settings()
        {
            InitializeComponent();
        }
        private const string OneClickProviderKey = "OneClick-Provider";
        private const string OneClickInstallerName = "BSMG-BeatSaberModInstaller";
        private static readonly string[] SupportedProtocols = new[] {"beatsaver" , "modelsaber" };
        private void settings_Load(object sender, EventArgs e)
        {
            metroTextBox1.Text = Properties.Settings.Default.BeatPath;
            foreach (var protocol in SupportedProtocols)
                RegisterProtocol(protocol);
        }
        private static void RegisterProtocol(string protocol)
        {
            using (var modsaberKey = Registry.ClassesRoot.CreateSubKey(protocol))
            using (var commandKey = modsaberKey.CreateSubKey(@"shell\open\command"))
            {
                modsaberKey.SetValue("URL Protocol", "", RegistryValueKind.String);
                modsaberKey.SetValue(OneClickProviderKey, OneClickInstallerName, RegistryValueKind.String);
                var exeLocation = Assembly.GetEntryAssembly().Location;
                commandKey.SetValue("", $"\"{exeLocation}\" \"--install\" \"%1\"");
            }
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.BeatPath = metroTextBox1.Text;
            Properties.Settings.Default.Save();
            MessageBox.Show("Everything is Ready dont run this again unless you changed the application path");
            Application.Exit();
        }
    }
}
