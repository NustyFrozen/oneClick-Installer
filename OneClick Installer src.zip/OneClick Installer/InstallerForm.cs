﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO.Compression;
using System.IO;
namespace OneClick_Installer
{
    public partial class InstallerForm : MetroFramework.Forms.MetroForm
    {
        string dataBinder;
        public InstallerForm(string data)
        {
            dataBinder = data;
            InitializeComponent();
        }
        string songPath ()
        {
            return Properties.Settings.Default.BeatPath + @"\Beat Saber_Data\CustomLevels";
        }
        string modelPath()
        {
            return Properties.Settings.Default.BeatPath + @"\CustomAvatars";
        }
        bool DownloadSong(string id)
        {

            metroLabel6.Text = "registering Items";
            string downloadApi = "https://beatsaver.com/api/download/key/";
            WebClient SongDownloader = new WebClient();
            Random randomHash = new Random();
            id = id.Replace("beatsaver:", "").Replace("/", "");
            string hash = Convert.ToString(randomHash.Next(10000, 20000000));

            metroLabel6.Text = "generating hash";
            string tempFile = Environment.CurrentDirectory + "songTemp - " + id + "-" + hash + ".zip";
            metroProgressSpinner1.Value = randomHash.Next(1, 20);

            metroLabel6.Text = "creating file";
            try
            {
                metroLabel6.Text = "Downloading temp zip file!";
                SongDownloader.DownloadFile(downloadApi + id, tempFile); //connection problem might be caused
                metroProgressSpinner1.Value = metroProgressSpinner1.Value + randomHash.Next(1, 50);
            } catch
            {
                return false;
            }
           try
            { //directory problem might be caused

                metroLabel6.Text = "extracting";
                Directory.CreateDirectory(songPath() +@"\" + id);
                ZipFile.ExtractToDirectory(tempFile, songPath() + @"\" + id);
                File.Delete(tempFile);
                metroProgressSpinner1.Value = randomHash.Next(1, 20);
            } catch
            {
                File.Delete(tempFile);
                return false;
            }

            metroLabel6.Text = "removing temp files";
            animclose.Start();
            return true;
        }
        bool DownloadModel(string id)
        {

            metroLabel6.Text = "registering Items";
            string downloadApi = "https://modelsaber.com/files/";
            WebClient modelDownloader = new WebClient();
            Random randomHash = new Random();
            string filename;
            filename = id.Replace("modelsaber:", "").Replace(".avatar","").Replace("%20"," ").Replace("avatar","");
            char[] withoutID = filename.ToCharArray();
            filename = "";
            for(int i = withoutID.Length - 1;i!= 0;i--)
            {
                if (withoutID[i] == '/') break;
                filename = withoutID[i] + filename;
            }
            metroLabel4.Text = filename;
            id = id.Replace("modelsaber://", "");
            metroLabel6.Text = "setting up everything";
            metroProgressSpinner1.Value = randomHash.Next(1, 20);
            metroLabel6.Text = "creating file";
            try
            {
                metroLabel6.Text = "Downloading file";
                modelDownloader.DownloadFile(downloadApi + id,modelPath() + @"\" + filename+ ".avatar"); //connection problem might be caused
                metroProgressSpinner1.Value = metroProgressSpinner1.Value + randomHash.Next(1, 50);
            }
            catch
            {
                return false;
            }
            animclose.Start();
            return true;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.BeatPath == "") { MessageBox.Show("please input your folder path before installing songs"); Application.Exit(); }
            this.Location = new Point(Screen.PrimaryScreen.Bounds.Width - this.Size.Width, Screen.PrimaryScreen.Bounds.Height - this.Size.Height - 40);
            this.Opacity = 0.8;
            metroLabel4.Text = dataBinder.Replace("beatsaver:", "").Replace("/", "").Replace("modelsaber:","").Replace("avatar","");
            if (dataBinder.Contains("modelsaber"))
            {
                if (!DownloadModel(dataBinder)) { MessageBox.Show("Error while installing the model,the model mighte already been installed or you have a connection problem"); Application.Exit(); }
            }
            else if (dataBinder.Contains("beatsaver")) if (!DownloadSong(dataBinder)) { MessageBox.Show("Error while installing the song,the song mighte already been installed or you have a connection problem"); Application.Exit(); }
        }

        private void animclose_Tick(object sender, EventArgs e)
        {
            if(metroProgressSpinner1.Value != 100)
            {
                
                metroProgressSpinner1.Value++;
                return;

            } else if (this.Opacity != 0)
            {
                metroLabel6.Text = "Installed!";
                this.Opacity = this.Opacity - 0.05;
                return;
            }
            Application.Exit();
        }
    }
}
